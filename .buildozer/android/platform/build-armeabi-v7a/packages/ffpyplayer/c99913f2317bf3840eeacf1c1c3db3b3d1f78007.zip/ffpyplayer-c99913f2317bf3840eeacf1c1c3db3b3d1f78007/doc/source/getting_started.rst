.. _started:

####################
  Getting Started
####################

.. toctree::
   :maxdepth: 2

   installation.rst
   examples.rst
