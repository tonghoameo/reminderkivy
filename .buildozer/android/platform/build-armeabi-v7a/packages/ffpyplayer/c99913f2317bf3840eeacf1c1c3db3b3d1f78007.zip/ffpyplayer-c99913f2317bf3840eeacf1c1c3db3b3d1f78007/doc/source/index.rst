.. FFPyPlayer documentation master file, created by
   sphinx-quickstart on Mon Dec 23 18:07:03 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to FFPyPlayer's documentation!
======================================

Contents:

.. toctree::
   :maxdepth: 2

   getting_started.rst
   api.rst

*  :ref:`genindex`
*  :ref:`modindex`
*  :ref:`search`
